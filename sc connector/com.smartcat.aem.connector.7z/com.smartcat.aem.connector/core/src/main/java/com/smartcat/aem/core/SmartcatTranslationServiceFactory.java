package com.smartcat.aem.core;

import com.adobe.granite.translation.api.TranslationConfig;
import com.adobe.granite.translation.api.TranslationConstants;
import com.adobe.granite.translation.api.TranslationException;
import com.adobe.granite.translation.api.TranslationService;
import com.adobe.granite.translation.core.common.AbstractTranslationServiceFactory;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Property;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.Service;

import java.util.*;

@Service
@Component
@Property(
        name = "translationFactory",
        value = {"smartcat"}
)
public class SmartcatTranslationServiceFactory extends AbstractTranslationServiceFactory {

    @Reference
    private TranslationConfig translationConfig;

    @Override
    public TranslationService createTranslationService(TranslationConstants.TranslationMethod translationMethod, String s) throws TranslationException {
        return new SmartcatTranslationService(super.factoryName, translationConfig);
    }

    @Override
    public List<TranslationConstants.TranslationMethod> getSupportedTranslationMethods() {
        ArrayList<TranslationConstants.TranslationMethod> ar = new ArrayList<TranslationConstants.TranslationMethod>();
        ar.add(TranslationConstants.TranslationMethod.MACHINE_TRANSLATION);
        ar.add(TranslationConstants.TranslationMethod.HUMAN_TRANSLATION);
        return ar;
    }

    @Override
    public Class<?> getServiceCloudConfigClass() {
        return SmartcatTranslationConfig.class;
    }
}