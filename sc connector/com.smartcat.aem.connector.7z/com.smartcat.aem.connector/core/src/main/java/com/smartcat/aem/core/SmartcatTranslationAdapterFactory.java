package com.smartcat.aem.core;

import javax.jcr.Node;

import org.apache.sling.api.adapter.AdapterFactory;
import org.apache.sling.api.resource.Resource;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.translation.core.TranslationCloudConfigUtil;

@Component(service = AdapterFactory.class)
public class SmartcatTranslationAdapterFactory implements AdapterFactory
{
    @Reference
    TranslationCloudConfigUtil cloudConfigUtil;

    private final Logger log = LoggerFactory.getLogger(getClass());

    private static final Class<SmartcatTranslationConfig> TRANSLATION_CLOUD_CONFIG_CLASS =
            SmartcatTranslationConfig.class;


    // ---------- AdapterFactory -----------------------------------------------

    public <AdapterType> AdapterType getAdapter(Object adaptable, Class<AdapterType> type)
    {
        log.trace("In function: getAdapter(Object,Claass<AdapterType>");

        if (adaptable instanceof Resource) {
            return getAdapter((Resource) adaptable, type);
        }
        if (adaptable instanceof Node) {
            return getAdapter((Node) adaptable, type);
        }
        log.warn("Unable to handle adaptable {}", adaptable.getClass().getName());
        return null;
    }

    public void setTranslationCloudConfigUtil(TranslationCloudConfigUtil configUtil)
    {
        cloudConfigUtil = configUtil;
    }

    /*
     * Adapter for Resource
     */
    @SuppressWarnings("unchecked")
    private <AdapterType> AdapterType getAdapter(Resource resource, Class<AdapterType> type)
    {
        log.trace("In function: getAdapter(Resource,Class<AdapterType>");

        if (type == TRANSLATION_CLOUD_CONFIG_CLASS
                && cloudConfigUtil.isCloudConfigAppliedOnImmediateResource(resource,
                SmartcatTranslationConfig.RESOURCE_TYPE))
        {
            return (AdapterType) new SmartcatTranslationConfigImpl(resource);
        }

        log.warn("Unable to adapt to resource of type {}", type.getName());
        return null;
    }
}
