package com.smartcat.aem.core;

import com.adobe.granite.translation.api.TranslationConfig;
import com.adobe.granite.translation.api.TranslationException;
import org.apache.sling.api.resource.ResourceResolver;

import java.util.Map;

public interface SmartcatTranslationConfig {
    public static final String RESOURCE_TYPE = "smartcat-connector/components/bootstrap-connector-cloudconfig";
}
