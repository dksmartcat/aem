package com.smartcat.aem.core;

import org.apache.sling.api.resource.Resource;

public class SmartcatTranslationConfigImpl implements SmartcatTranslationConfig {
    public SmartcatTranslationConfigImpl(Resource translationConfigResource)
    {
    }
}
