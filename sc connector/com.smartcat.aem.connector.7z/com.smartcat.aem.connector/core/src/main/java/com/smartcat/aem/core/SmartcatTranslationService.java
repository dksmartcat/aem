package com.smartcat.aem.core;

import com.adobe.granite.translation.api.TranslationConfig;
import com.adobe.granite.translation.api.TranslationConstants;
import com.adobe.granite.translation.api.TranslationException;
import com.adobe.granite.translation.api.TranslationMetadata;
import com.adobe.granite.translation.api.TranslationObject;
import com.adobe.granite.translation.api.TranslationScope;
import com.adobe.granite.translation.api.TranslationService;
import com.adobe.granite.translation.api.TranslationState;
import com.adobe.granite.translation.api.TranslationConstants.TranslationStatus;
import com.adobe.granite.translation.api.TranslationException.ErrorCode;
import java.io.InputStream;
import java.util.Collections;
import java.util.Date;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class SmartcatTranslationService extends AbstractSmartcatHumanTranslationService implements TranslationService {

    SmartcatTranslationService(String name, TranslationConfig translationConfig) {
        super(Collections.emptyMap(), name, "Smartcat label", translationConfig);
    }

    @Override
    public Map<String, String> supportedLanguages() {
        return null;
    }

    @Override
    public boolean isDirectionSupported(String s, String s1) throws TranslationException {
        return false;
    }

    @Override
    public String detectLanguage(String s, TranslationConstants.ContentType contentType) throws TranslationException {
        return null;
    }

    @Override
    public String createTranslationJob(String s, String s1, String s2, String s3, Date date, TranslationState translationState, TranslationMetadata translationMetadata) throws TranslationException {
        return null;
    }

    @Override
    public void updateTranslationJobMetadata(String s, TranslationMetadata translationMetadata, TranslationConstants.TranslationMethod translationMethod) throws TranslationException {

    }

    @Override
    public String uploadTranslationObject(String s, TranslationObject translationObject) throws TranslationException {
        return null;
    }

    @Override
    public TranslationScope getFinalScope(String s) throws TranslationException {
        return null;
    }

    @Override
    public TranslationStatus updateTranslationJobState(String s, TranslationState translationState) throws TranslationException {
        return null;
    }

    @Override
    public TranslationStatus getTranslationJobStatus(String s) throws TranslationException {
        return null;
    }

    @Override
    public InputStream getTranslatedObject(String s, TranslationObject translationObject) throws TranslationException {
        return null;
    }

    @Override
    public TranslationStatus updateTranslationObjectState(String s, TranslationObject translationObject, TranslationState translationState) throws TranslationException {
        return null;
    }

    @Override
    public TranslationStatus getTranslationObjectStatus(String s, TranslationObject translationObject) throws TranslationException {
        return null;
    }
}

